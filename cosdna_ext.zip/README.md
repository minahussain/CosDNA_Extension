# CosDNA Extension - Chrome

Download the chrome extension [here](https://chrome.google.com/webstore/detail/cosdna-extension/apjcnjbhemlgjpfkbfdcmgopangnienl?hl=en-US&gl=US).

You can highlight text and open a new CosDNA search tab of your selection using this extension.

## Icon

Icon made using HTML Canvas.

## Updates

Update 1.2: added context menu.

Update 1.3: updated jquery to version 3.3.1

Future plans to add as a Firefox extension.
